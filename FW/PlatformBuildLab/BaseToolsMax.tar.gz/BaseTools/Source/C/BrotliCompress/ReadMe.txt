It is based on the Brotli v0.5.2.
Brotli was released on the website https://github.com/google/brotli.
