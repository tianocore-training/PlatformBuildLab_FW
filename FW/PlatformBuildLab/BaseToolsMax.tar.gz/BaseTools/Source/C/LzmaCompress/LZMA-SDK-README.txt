LzmaCompress is based on the LZMA SDK 16.04.  LZMA SDK 16.04
was placed in the public domain on 2016-10-04.  It was
released on the http://www.7-zip.org/sdk.html website.